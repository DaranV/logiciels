#ifndef _ITEM_
#define _ITEM_
/**
* @file Item.h
* @brief Projet SDA
* @author SOK Alexis - VIGNARAJAH Daran
* @version 2 19/12/18
*/

typedef unsigned int Item;

#endif // !_ITEM_

